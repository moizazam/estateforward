import {Pool} from 'pg';
import {timingSafeEqual} from 'node:crypto';
let pool:Pool|undefined;
export function db(){if(!process.env.DATABASE_URL)throw new Error('DATABASE_URL not configured');if(!pool)pool=new Pool({connectionString:process.env.DATABASE_URL,max:5,ssl:process.env.DB_SSL==='true'?{rejectUnauthorized:true}:undefined});return pool;}
export function validAdmin(req:Request){const secret=process.env.ADMIN_API_KEY;const candidate=req.headers.get('x-admin-key')||'';if(!secret||!candidate)return false;const a=Buffer.from(candidate),b=Buffer.from(secret);return a.length===b.length&&timingSafeEqual(a,b);}
export function bad(message:string,status=400){return Response.json({error:message},{status,headers:{'Cache-Control':'no-store'}})}
export function clean(v:unknown,max=100){return typeof v==='string'?v.trim().slice(0,max):''}
export function isConfigured(){return Boolean(process.env.DATABASE_URL)}
export async function body(req:Request){if(Number(req.headers.get('content-length')||0)>12000)throw Error('Request too large');const raw=await req.text();if(raw.length>12000)throw Error('Request too large');return JSON.parse(raw)}

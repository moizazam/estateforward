# ESTATEforward — Website Development Preview

A responsive Next.js/TypeScript frontend based on the provided ESTATEforward requirements and **the original user-supplied logo** (`public/estateforward-original-logo.png`, cropped from the uploaded reference without redrawing).

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000. For production build, run `npm run build` then `npm start`.

## Included

- Home page, property catalogue, property detail pages, About, Services, Projects, Agents, Insights, Careers, FAQ, Contact, Privacy and Submit Property.
- Responsive navigation, property cards, category navigation, hero, search, filtering, sorting and mobile layouts.
- Contact and property submission forms that store **only in the browser's localStorage**, with a clearly labeled local demo dashboard at `/dashboard`.
- Original logo extracted from user-provided image; brown/cream/gold theme.

## Not production-ready / remaining development

**This is a frontend MVP, not a deployed full-stack real estate system.** It has no server database, authentication, verified listings, media upload, actual email/WhatsApp sending, admin authorization, agent permissions, CRM, financial ledger, audit logging or payments. All six property listings are clearly labeled illustrative/demo, not real inventory. Unsplash images are visual placeholders and require licensing/approval before production. Forms store locally only and should not be used for sensitive information.

### Proposed backend work

1. PostgreSQL schema: properties, locations, users, roles, agents, media, enquiries, submissions, transactions, ledger, audit events, editorial content.
2. Auth with MFA for privileged users, role-based authorization and secure session handling.
3. Protected media upload and moderation; signed storage URLs.
4. Submission verification, draft/review/approve/publish workflows.
5. Secure lead management and assigned agent follow-ups.
6. Internal CRM, buyer/seller records, transaction history and reconciled ledger after finance rule sign-off.
7. CMS for projects, legal articles, news, FAQs and maps.
8. Consent/privacy notices, anti-spam, backups, monitoring and production QA.

## Required business confirmations

Official brand assets/hex codes; final contact and social links; inventory and project names; exact location taxonomy; who can submit and approve; privacy policy; financial definitions; agent roles; whether charity is informational or transactional.

## Phase 2: server-side intake and moderation (implemented as starter backend)

- PostgreSQL schema: `db/schema.sql` (enquiries and property submissions, pending/approved/rejected states).
- Public POST endpoints: `/api/enquiries`, `/api/submissions`; submissions default to pending.
- Private GET `/api/admin/records` and PATCH `/api/admin/submissions/:id` with `x-admin-key` header (secret configured only on server).
- Forms now POST to the server and show explicit errors if no database is configured. No more localStorage of private customer data.
- To enable: configure `.env.example` values in `.env.local`, run `psql "$DATABASE_URL" -f db/schema.sql`, install dependencies, build and deploy.

**Security caveats:** The API key is a development-stage administrative interface, not a replacement for user authentication. Before public launch add MFA-backed sessions, per-role permissions, audit logs, rate limiting/CAPTCHA, consent retention policy, encrypted backups, email alerts, media storage, and verified publication pipeline. The approval status is internal only; it does not automatically publish records as public listings. Do not expose the admin key in browser JavaScript. The site must not be advertised as fully production-ready.

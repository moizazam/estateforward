-- ESTATEforward phase 2: server-side intake and moderation
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS enquiries (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name varchar(120) NOT NULL,
 phone varchar(40) NOT NULL, message text NOT NULL,
 consent boolean NOT NULL CHECK(consent), status varchar(20) NOT NULL DEFAULT 'new'
 CHECK(status IN ('new','contacted','closed')), created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS property_submissions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name varchar(120) NOT NULL,
 phone varchar(40) NOT NULL, email varchar(254), role varchar(40) NOT NULL,
 purpose varchar(20) NOT NULL, category varchar(80) NOT NULL,
 city varchar(100) NOT NULL, society varchar(160) NOT NULL,
 sector varchar(100), area numeric(12,2) NOT NULL CHECK(area>0),
 unit varchar(20) NOT NULL, demand numeric(18,2) NOT NULL CHECK(demand>=0),
 description text NOT NULL, features text,
 consent boolean NOT NULL CHECK(consent),
 status varchar(20) NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
 created_at timestamptz NOT NULL DEFAULT now(), reviewed_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_submissions_status ON property_submissions(status,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_enquiries_status ON enquiries(status,created_at DESC);

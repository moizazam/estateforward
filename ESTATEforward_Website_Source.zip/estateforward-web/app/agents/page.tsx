import {InfoPage} from '@/components/InfoPages';export default function Page(){return <InfoPage slug="agents"/>}
